﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WebApplication1
{
    public partial class LoginPage : System.Web.UI.Page
    {
        Controller controller;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LogIn_Click(object sender, EventArgs e)
        {

        }

        protected void InsertCustomer_Click(object sender, EventArgs e)
        {
            controller = new Controller();
            int r = controller.Insert_Customer(UserName.Text, 'M', TextBox_BDATE.Text, TextBox_Address.Text, Convert.ToInt32(TextBox_Phone.Text));
            if(r!=0)
            {
                FeedBack.Text = "DONE";
            }
        }
    }
}