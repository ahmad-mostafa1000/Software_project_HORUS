﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



using System.Data;
using System.Configuration;
using System.Data.SqlClient;


namespace WebApplication1
{
    public partial class Update_Food_Price : System.Web.UI.Page
    {
        Controller controller;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                feedback.Text = "";
                //DropDownList_ID.Items.Clear();
                //DropDownList_ID.Items.Insert(0, new ListItem("<Select Customer", "0"));
                controller = new Controller();
                DataTable dt = controller.FoodIDandName();
                DropDownList_ID.DataSource = dt;
                DropDownList_ID.DataTextField = "Name";
                DropDownList_ID.DataValueField = "ID";
                DropDownList_ID.DataBind();
            }
        }

        protected void Button_LogOut_Click(object sender, EventArgs e)
        {
            Server.Transfer("LOG_IN.aspx", true);
        }

        protected void Button_Home_Click(object sender, EventArgs e)
        {
            Server.Transfer("Manager.aspx", true);
        }

        protected void Button_updatecash_Click(object sender, EventArgs e)
        {
            controller = new Controller();

            if (DropDownList_ID.Text == "0")
            {
                feedback.Text = "PLEASE, Choose a food name";
            }
            else if (TextBox_price.Text == "")
            {
                feedback.Text = "PLEASE, ENTER PRICE!!";
            }
            else
            {
                feedback.Text = "";

                int r = controller.update_food_price(Convert.ToInt32(DropDownList_ID.Text), Convert.ToSingle(TextBox_price.Text));

                if (r != 0)
                {
                    feedback.Text = "DONE";
                }
                else
                {
                    feedback.Text = "Contact Your DBMS Manager";
                }
            }
        }
    }
}