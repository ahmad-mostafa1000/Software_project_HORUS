﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



using System.Data;
using System.Configuration;
using System.Data.SqlClient;



namespace WebApplication1
{
    public partial class Customer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void button_viewmenu_Click(object sender, EventArgs e)
        {


            Server.Transfer("Customer_ViewMenu.aspx", true);
           
        }

        protected void button_viewOrders_Click(object sender, EventArgs e)
        {
            Server.Transfer("Customer_ListOfOrders.aspx", true);
        }

        protected void Button_LogOut_Click(object sender, EventArgs e)
        {
            Server.Transfer("LOG_IN.aspx", true);
        }
    }
}