﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WebApplication1
{
    public static class StoredProcedures
    {
        public static string InsertCustomer = "InsertCustomer";
    }
}
       // public static string Project_Details = "ProjDetails111";

       // public static string Statistics = "statisticss";
       // public static string average_salary = "AvgSalary";
       // public static string MaxSalary = "MaxSalary";
       // public static string MinSalary = "MinSalary";
       // //----------------------------------------------------------------
       
       // // public static string employee_servers = "get_serverr_accessS";
       // public static string EmployeeServer = "EmployeeServer";
       // public static string get_employee_Data = "get_employee_DataA";
       // public static string employee_projects = "employee_projectSs";
       // public static string employee_reports = "get_all_reportssS"; 
       // //   public static string Employee_Project_Reports = "EmployeeProjectReports";
       // //------------------------------------------------------
       // public static string insertDepartment = "insertDepartmenttt";
       // public static string insertProject = "insertProject";
       // //------------------------------------------------------------- 
       // public static string soft_ware = "get_sw";
       // public static string All_software_info = "All_software_info";
       // //-------------------------------------------------------------
       // public static string update_trans = "UPDATE_TRANSPORTATION";
       ////-------------------------------------------------------------------
       // public static string no_of_machines = "NUMBER_OF_MACHINe";
       // public static string no_of_employees = "NUMBER_OF_EMPLOYEe";
       // public static string manager= "MANAGERr";
       // public static string no_of_projects = "NUMBER_OF_PROJ";
       // public static string no_of_products = "NUMBER_OF_PRODUCTS";
       // //---------------------------------------------------------------------------------------
       // public static string all_Out_sourcing = "All_OutSourcing_info"; 
       // //-------------------------------------------------------------------------------
       // public static string insert_outsourcing = "Insert_OutSourcing"; 
       // //-------------------------------------------------------------------------------------------
       // public static string insert_server = "Insert_server";
       // public static string calculate_free_space = "calc_free_space";
       // //--------------------------------------------------------------------------
       // public static string update_place = "update_place";
       // //---------------------------------------------------------------------
       // public static string calculate_revenue = "calc_revenue";
       // public static string add_product = "Insert_product";
       // public static string insert_dep_forproduct = "insert_dep_for_product";
       // //----------------------------------------------------------------
       // public static string update_server = "update_server";
       // //------------------------------------------------------------------------
       // public static string update_employee_bus = "update_bus";
       // public static string add_report = "add_report";
       // public static string update_bus_late = "UPDATE_TRANSPORTATION";

//    }
//}
