﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;




using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class cheif_bending_orders : System.Web.UI.Page
    {
        Controller controller;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                feedback_serve.Text = "";
                feedback_ready.Text = "";
                //DropDownList_ID.Items.Clear();
                //DropDownList_ID.Items.Insert(0, new ListItem("<Select Customer", "0"));
                controller = new Controller();
                DataTable dt = controller.View_List_CheifOrderList_NotReady();
                DropDownList1.DataSource = dt;
                DropDownList1.DataTextField = "ID";
                DropDownList1.DataValueField = "ID";
                DropDownList1.DataBind();

                dt = controller.Cust_Ready();
                DropDownList2.DataSource = dt;
                DropDownList2.DataTextField = "Order ID";
                DropDownList2.DataValueField = "Order ID";
                DropDownList2.DataBind();
            }
        }

        protected void Button_isready_Click(object sender, EventArgs e)
        {
             controller = new Controller();

             if (DropDownList1.Text == "0")
             {
                 feedback_serve.Text = "";
                 feedback_ready.Text = "";
                 feedback_ready.Text = "PLEASE, Choose Order ID";
             }
             else
             {
                 feedback_ready.Text = "";

                 int r = controller.changeOrderState(Convert.ToInt32(DropDownList1.Text), "R");
                 if (r != 0)
                 {
                     feedback_ready.Text = "DONE";
                     //To reset everything
                     feedback_serve.Text = "";
                     //feedback_ready.Text = "";
                     DropDownList1.Items.Clear();
                     DropDownList1.Items.Insert(0, new ListItem("<Select ID", "0"));
                     DropDownList2.Items.Clear();
                     DropDownList2.Items.Insert(0, new ListItem("<Select ID", "0"));
                     controller = new Controller();
                     DataTable dt = controller.View_List_CheifOrderList_NotReady();
                     DropDownList1.DataSource = dt;
                     DropDownList1.DataTextField = "ID";
                     DropDownList1.DataValueField = "ID";
                     DropDownList1.DataBind();

                     dt = controller.Cust_Ready();
                     DropDownList2.DataSource = dt;
                     DropDownList2.DataTextField = "Order ID";
                     DropDownList2.DataValueField = "Order ID";
                     DropDownList2.DataBind();

                     DataGrid1.DataBind();
                     DataGrid2.DataBind();
                 }
                 else
                 {
                     feedback_ready.Text = "Contact Your DBMS Manager";
                     return;
                 }
             }
        }

        protected void Button_isserver_Click(object sender, EventArgs e)
        {
            controller = new Controller();

            if (DropDownList2.Text == "0")
            {
                feedback_serve.Text = "";
                feedback_ready.Text = "";
                feedback_serve.Text = "PLEASE, Choose Order ID";
            }
            else
            {
                feedback_serve.Text = "";

                int r = controller.changeOrderState(Convert.ToInt32(DropDownList2.Text), "S");
                if (r != 0)
                {
                    feedback_serve.Text = "DONE";
                    //To reset everything
                    //feedback_serve.Text = "";
                    feedback_ready.Text = "";
                    DropDownList1.Items.Clear();
                    DropDownList1.Items.Insert(0, new ListItem("<Select ID", "0"));
                    DropDownList2.Items.Clear();
                    DropDownList2.Items.Insert(0, new ListItem("<Select ID", "0"));
                    controller = new Controller();
                    DataTable dt = controller.View_List_CheifOrderList_NotReady();
                    DropDownList1.DataSource = dt;
                    DropDownList1.DataTextField = "ID";
                    DropDownList1.DataValueField = "ID";
                    DropDownList1.DataBind();

                    dt = controller.Cust_Ready();
                    DropDownList2.DataSource = dt;
                    DropDownList2.DataTextField = "Order ID";
                    DropDownList2.DataValueField = "Order ID";
                    DropDownList2.DataBind();

                    DataGrid1.DataBind();
                    DataGrid2.DataBind();
                }
                else
                {
                    feedback_serve.Text = "Contact Your DBMS Manager";
                    return;
                }
            }
        }

        protected void Button_Home_Click(object sender, EventArgs e)
        {
            Server.Transfer("Cheif.aspx", true);
        }

        protected void Button_LogOut_Click(object sender, EventArgs e)
        {
            Server.Transfer("LOG_IN.aspx", true);
        }
    }
}