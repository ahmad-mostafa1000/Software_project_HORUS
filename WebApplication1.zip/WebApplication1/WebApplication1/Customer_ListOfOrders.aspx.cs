﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Customer_ListOfOrders : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button_refresh_Click(object sender, EventArgs e)
        {
            DataGrid1.DataBind();
            DataGrid2.DataBind();
        }

        protected void Button_Home_Click(object sender, EventArgs e)
        {
            Server.Transfer("Customer.aspx", true);

        }

        protected void Button_LogOut_Click(object sender, EventArgs e)
        {
            Server.Transfer("LOG_IN.aspx", true);

        }
    }
}