﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Web;

namespace WebApplication1
{
    public class Controller
    {
        DBManager dbMan;
        public Controller()
        {
            dbMan = new DBManager();
        }


        public void TerminateConnection()
        {
            dbMan.CloseConnection();
        }


        public int Insert_Customer(string n, char s, string bd, string ad, int ph)
        {

            string StoredProcedureName = StoredProcedures.InsertCustomer;
            Dictionary<string, object> Parameters = new Dictionary<string, object>();
            Parameters.Add("@name", n);
            Parameters.Add("@Sex", s);
            Parameters.Add("@BDate", bd);
            Parameters.Add("@Adress", ad);
            Parameters.Add("@Phone", ph);

            return dbMan.ExecuteNonQuery(StoredProcedureName, Parameters);
        }

    }
}

//        //-------------------------------statical-------------------------------------------

//        public DataTable get_statics()
//        {
//            string StoredProcedureName = StoredProcedures.Statistics;
//            return dbMan.ExecuteReader(StoredProcedureName, null);

//        }
//        public DataTable get_Max()
//        {
//             string StoredProcedureName = StoredProcedures.MaxSalary;
//            return dbMan.ExecuteReader(StoredProcedureName, null);
        
//        }
//        //public DataTable get_Min()
//        //{
//        //    string StoredProcedureNamee = StoredProcedures.MinSalary;
//        //    return dbMan.ExecuteReader(StoredProcedureNamee, null);
//        //  }

//        public DataTable get_Avg()
//        {
//            string StoredProcedureName2 = StoredProcedures.average_salary;
//            return dbMan.ExecuteReader(StoredProcedureName2, null);
//        }
////----------------------------------    EMPLOYEE SERVER------------------------------------------------
        

      

//        //---------------------------------------department info----------------------------------------------------
//        public DataTable noofmachines(string x)
//        {
//            string StoredProcedureName = StoredProcedures.no_of_machines;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@depno", x);

//            return dbMan.ExecuteReader(StoredProcedureName, Parameters);
//        }
//        public DataTable noofemployees(string x)
//        {
//            string StoredProcedureName = StoredProcedures.no_of_employees;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@depno", x);
//            return dbMan.ExecuteReader(StoredProcedureName, Parameters);
//        }

//        public DataTable get_manager(string x)
//        {
//            string StoredProcedureName = StoredProcedures.manager;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@depno", x);
//            return dbMan.ExecuteReader(StoredProcedureName, Parameters);
//        }

//        public DataTable noof_projects(string x)
//        {
//            string StoredProcedureName = StoredProcedures.no_of_projects;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@depno", x);
//            return dbMan.ExecuteReader(StoredProcedureName, Parameters);
//        }

//        public DataTable noof_products(string x)
//        {
//            string StoredProcedureName = StoredProcedures.no_of_products;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@depno", int.Parse(x));
//            return dbMan.ExecuteReader(StoredProcedureName, Parameters);
//        }
//        public DataTable get_Department_id() //get department for combobox
//        {
//            string query = "SELECT DISTINCT department_id FROM Department;";
//              return dbMan.ExecuteReader(query);
//        }
//        //-----------------------------------------get employee info----------------------------------------
//        public DataTable get_employees() //get employees for combobox
//        {
//            string query = "SELECT DISTINCT Employee_id FROM Employee;";


//            return dbMan.ExecuteReader(query);
//        }
//        public DataTable get_Employee_info(string x)
//        {
//            string StoredProcedureName = StoredProcedures.get_employee_Data;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@employee_id", x);

//            return dbMan.ExecuteReader(StoredProcedureName, Parameters);
//        }
//        public DataTable get_Employee_projects(string x)
//        {
//            string StoredProcedureName = StoredProcedures.employee_projects;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@employee_id", x);

//            return dbMan.ExecuteReader(StoredProcedureName, Parameters);
//        }

//        public DataTable get_server(string x)
//        {
//            string StoredProcedureName = StoredProcedures.EmployeeServer;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@SSN", x);

//            return dbMan.ExecuteReader(StoredProcedureName, Parameters);
//        }
//        public DataTable get_Employee_reports(string x)
//        {
//            string StoredProcedureName = StoredProcedures.employee_reports;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@employee_id", x);

//            return dbMan.ExecuteReader(StoredProcedureName, Parameters);
//        }
//        //-----------------------------------------------------InsertDepartment--------------------------------------------------
//        public int InsertDepartment(int depid, string name, int managerid, int floor,int room)
//        {

//            string StoredProcedureName = StoredProcedures.insertDepartment;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@Dept_id", depid);
//            Parameters.Add("@Name", name);
//            Parameters.Add("@manager_id", managerid);
//            Parameters.Add("@floor", floor);
//            Parameters.Add("@room", room);

//            return dbMan.ExecuteNonQuery(StoredProcedureName, Parameters);
//        }

//        //=------------------------------------INSERT PROJECT----------------------------------------
//        public int Insert_Project(int q, string p, string n, string e,int x)
//        {

//            string StoredProcedureName = StoredProcedures.insertProject;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@Project_id",q);
//            Parameters.Add("@Name", p);
//            Parameters.Add("@start_date",n);
//            Parameters.Add("@finishing_date", e);
//            Parameters.Add("@department_id", x);

//            return dbMan.ExecuteNonQuery(StoredProcedureName, Parameters);
//        }
//        //---------------------------------------------PROJECT DETAILS-----------------------------------------------------
//        public DataTable get_proj_id() //get department for combobox
//        {
//            string query = "SELECT DISTINCT Project_id FROM Project;";
//            return dbMan.ExecuteReader(query);
//        }

//        public DataTable  project_details(string x)
//        {
//            string StoredProcedureName = StoredProcedures.Project_Details;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@Project_id", x);

//            return dbMan.ExecuteReader(StoredProcedureName, Parameters);
//        }
//        //------------------------------------------get SOFTWARE----------------------------------------------
//        public DataTable get_software(string x)
//        {
//            string StoredProcedureName = StoredProcedures.soft_ware;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@sw_id", x);

//            return dbMan.ExecuteReader(StoredProcedureName, Parameters);
//        }

//        public DataTable get_all_software_info()
//        {
//            string StoredProcedureName2 = StoredProcedures.All_software_info;
//            return dbMan.ExecuteReader(StoredProcedureName2, null);
//        }

//        public DataTable get_sw_id() //get department for combobox
//        {
//            string query = "SELECT DISTINCT Sw_id  FROM Software ;";
//            return dbMan.ExecuteReader(query);
//        }
////------------------------------------------------------OUT SOURCING (view)-------------------------------------------------------------
//        public DataTable get_all_OutSourcing_info()
//        {
//            string StoredProcedureName2 = StoredProcedures.all_Out_sourcing;
//            return dbMan.ExecuteReader(StoredProcedureName2, null);
//        }
// //----------------------------------------------------ADD OUTSOURCING---------------------------------------------
//        public int Insert_OutSourcing( string name,string service)
//        {

//            string StoredProcedureName = StoredProcedures.insert_outsourcing;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@company_name", name);
//            Parameters.Add("@service", service);
//           return dbMan.ExecuteNonQuery(StoredProcedureName, Parameters);
//        } 

//        //---------------------------------------------ADD SERVERS-------------------------------------------------
//        public int insert_server(string name, string status,int cap,int use)
//        {

//            string StoredProcedureName = StoredProcedures.insert_server;
         

//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@server_name",name);
//            Parameters.Add("@status",status);
//            Parameters.Add("@capacity",cap);
//            Parameters.Add("@usage",use);

//            return dbMan.ExecuteNonQuery(StoredProcedureName, Parameters);
//        }
//        public int calculate_free_space() //calculating free space
//        {

//            string StoredProcedureName = StoredProcedures.calculate_free_space;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();  /////?????????????????????????????

//            return dbMan.ExecuteNonQuery(StoredProcedureName, Parameters);
//        }
//        public DataTable get_status_id() //get false or true for combobox
//        {
//            string query = "SELECT DISTINCT status FROM servers;";
//            return dbMan.ExecuteReader(query);
//        }

//        //---------------------------------------------------UPDATE PLACE----------------------------------------
//        public int Update_place(int depid, int cap, int use)
//        {

//            string StoredProcedureName = StoredProcedures.update_place;

//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@dep_id", depid);
//            Parameters.Add("@floor", cap);
//            Parameters.Add("@room", use);

//            return dbMan.ExecuteNonQuery(StoredProcedureName, Parameters);
//        }


//        //-----------------------------------------ADD PRODUCT----------------------------------------
//        public int ADD_Product(int q, string p,int n, int e, int x)
//        {

//            string StoredProcedureName = StoredProcedures.add_product;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@product_id", q);
//            Parameters.Add("@name", p);
//            Parameters.Add("@unit_cost", n);
//            Parameters.Add("@unit_price", e);
//            Parameters.Add("@no_of_sales", x);

//            return dbMan.ExecuteNonQuery(StoredProcedureName, Parameters);
//        }

//        public int calculate_revenue() //calculating revenue
//        {

//            string StoredProcedureName = StoredProcedures.calculate_revenue;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();  

//            return dbMan.ExecuteNonQuery(StoredProcedureName, Parameters);
//        }
//        public int insert_dep_forproduct(int q,int y) //inserting department for production relation
//        {

//            string StoredProcedureName = StoredProcedures.insert_dep_forproduct;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();

//            Parameters.Add("@product_id", q);
//            Parameters.Add("@dep_id", y);

//            return dbMan.ExecuteNonQuery(StoredProcedureName, Parameters);
//        }

//        //---------------------------------------------------UPDATE SERVER-------------------------
//        public int update_server(string q, string p)
//        {

//            string StoredProcedureName = StoredProcedures.update_server;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@server_name", q);
//            Parameters.Add("@status", p);
            

//            return dbMan.ExecuteNonQuery(StoredProcedureName, Parameters);
//        }
//        public DataTable get_server_name() //get false or true for combobox
//        {
//            string query = "SELECT DISTINCT Server_name FROM servers;";
//            return dbMan.ExecuteReader(query);
//        }

//        //------------------------------------ADD REPORT----------------------------------------------------
//        public int ADD_report(int q, int p, string n)
//        {
//          string StoredProcedureName = StoredProcedures.add_report;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@employee_id", q);
//            Parameters.Add("@project_id", p);
//            Parameters.Add("@date", n);
            
//       return dbMan.ExecuteNonQuery(StoredProcedureName, Parameters);
//        }

//        //-----------------------------------ASK FOR TRANSPORTAION-----------------------------------------

//        public int update_bus(int q, int p)
//        {
//            string StoredProcedureName = StoredProcedures.update_employee_bus;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//            Parameters.Add("@Employee_id", q);
//            Parameters.Add("@bus_id", p);
          

//            return dbMan.ExecuteNonQuery(StoredProcedureName, Parameters);
//        }

//        public DataTable get_bus_id() // combobox
//        {
//            string query = "SELECT DISTINCT Bus_id FROM Transportation;";
//            return dbMan.ExecuteReader(query);
//        }
//        //-------------------------------------------------REPORT TRANSPORTATION  (LATE)-----------------------------------
//        public int update_bus_Late(int q)
//        {
//            string StoredProcedureName = StoredProcedures.update_bus_late;
//            Dictionary<string, object> Parameters = new Dictionary<string, object>();
//             Parameters.Add("@bus_id", q);


//            return dbMan.ExecuteNonQuery(StoredProcedureName, Parameters);
//        }
//        //public DataTable get_proj_id() //get BUS ID for combobox
//        //{
//        //    string query = "SELECT DISTINCT Bus_id FROM Transportation;";
//        //    return dbMan.ExecuteReader(query);
//        //}

//        //public DataTable project_details(string x)
//        //{
//        //    string StoredProcedureName = StoredProcedures.Project_Details;
//        //    Dictionary<string, object> Parameters = new Dictionary<string, object>();
//        //    Parameters.Add("@Project_id", x);

//        //    return dbMan.ExecuteReader(StoredProcedureName, Parameters);
//        //}
//        //------------------------------------------------------------------------------------------------------------------------
//        //public DataTable SelectDepNum()
//        //{
//        //    string StoredProcedureName = StoredProcedures.SelectDepartmentNum;
//        //    return dbMan.ExecuteReader(StoredProcedureName, null);

//        //}
//        //public DataTable SelectDepLoc()
//        //{
//        //    String StoredProcedureName = StoredProcedures.SelectDepartmentLocation;
//        //    return dbMan.ExecuteReader(StoredProcedureName, null);

//        //}

//        //public DataTable SelectProject(string location)
//        //{
//        //    String StoredProcedureName = StoredProcedures.RetrieveProject;
//        //    Dictionary<string, object> Parameters = new Dictionary<string, object>();
//        //    Parameters.Add("@location", location);
//        //    return dbMan.ExecuteReader(StoredProcedureName, Parameters);
//        //}
//    }
//}
