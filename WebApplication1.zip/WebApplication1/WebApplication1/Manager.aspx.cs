﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WebApplication1
{ 
    public partial class LoginPage : System.Web.UI.Page
    {
     

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LogIn_Click(object sender, EventArgs e)
        {
            Server.Transfer("LOG_IN.aspx", true);
        }

        protected void InsertCustomer_Click(object sender, EventArgs e)
        {
            
           
        }
   ///////////////////////////////////////////////////////////////////////////////////////////////////////////        
        protected void Inserting_customer_Click(object sender, EventArgs e)//choose to insert customer
        {
            Server.Transfer("add_customer.aspx", true);
        
        }

 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        protected void Button_addmeal_Click(object sender, EventArgs e)//adding meal
        {
            
        }

        protected void adding_meal_Click(object sender, EventArgs e)
        {
            Server.Transfer("Add_food.aspx", true);
        }

        protected void button_add_money_Click(object sender, EventArgs e)
        {
            Server.Transfer("add_money.aspx", true);
        }

        protected void button_Update_meal_Click(object sender, EventArgs e)
        {
            Server.Transfer("Update_Food_Price.aspx", true);
        }
    }
}