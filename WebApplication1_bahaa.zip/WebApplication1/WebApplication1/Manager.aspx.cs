﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WebApplication1
{ 
    public partial class LoginPage : System.Web.UI.Page
    {
        Controller controller;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LogIn_Click(object sender, EventArgs e)
        {

        }

        protected void InsertCustomer_Click(object sender, EventArgs e)
        {
            
           
        }
   ///////////////////////////////////////////////////////////////////////////////////////////////////////////        
        protected void Inserting_customer_Click(object sender, EventArgs e)//choose to insert customer
        {
            Server.Transfer("add_customer.aspx", true);
        }

 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        protected void Button_addmeal_Click(object sender, EventArgs e)//adding meal
        {
            //controller = new Controller();
            //int r = controller.add_meal(TextBox1_food.Text, Convert.ToSingle(TextBox2price.Text), Convert.ToSingle(TextBox3time.Text));

            //case lw mfeesh 7aga d5lt mn el user
            //if (r != 0)
            //{
            //    FeedBack.Text = "DONE";
            //}
            //else
            //{
            //    FeedBack.Text = "PLEASE, MAKE SURE YOU ENTERED ALL VALUES RIGHT";
            //}
        
        }
    }
}