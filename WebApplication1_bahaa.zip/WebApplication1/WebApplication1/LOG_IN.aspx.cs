﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class LOG_IN : System.Web.UI.Page
    {
        Controller controller=new Controller();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void button_login_Click(object sender, EventArgs e)
        {
            int r = controller.log_in(textBox_username.Text, textBox_pass.Text);
            if (r != 0)
            {
                feedback_username.Text = "DONE";
                feedback_pass.Text = "DONE";
            if(r==0)//admin
            {

            }
            if(r==1)//customer
             {

             }
            else 
            { 
            
            }//cheif   
            
            }
           ////////////not successful////////////////////
            else
            {
                feedback_username.Text = "PLEASE CHECK USER NAME ";
                feedback_pass.Text = "PLEASE CHECK PASSWORD";
            }

        }
    }
}