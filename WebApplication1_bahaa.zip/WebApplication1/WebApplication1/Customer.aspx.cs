﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



using System.Data;
using System.Configuration;
using System.Data.SqlClient;



namespace WebApplication1
{
    public partial class Customer : System.Web.UI.Page
    {
        Controller controller;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void button_viewmenu_Click(object sender, EventArgs e)
        {

          
            DataTable dt = controller.view_menu();


            DataGrid_viewmenu.DataSource = dt;
            /////////////////
         //   DataTable r = controller.view_menu();
           // SqlDataAdapter sda = new SqlDataAdapter();
            //sda.Fill(r);
           
           
        }
    }
}